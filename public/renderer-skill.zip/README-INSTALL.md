# Renderer — Claude Code Skill

This package installs the **Renderer** slash command into Claude Code. Once installed, type `/renderer` in any Claude Code session to activate the full novel writing system pipeline.

---

## What this skill does

`/renderer` primes Claude Code with the complete Renderer pipeline:

- All pipeline phases (context packet → draft → review → canon assembly → artifact updates)
- All pass types and their triggers
- All 14 evaluation dimensions and their gates
- All 8 named failure patterns (over-explanation, AI register, annotation, etc.)
- Document authority rules, P1 error handling, artifact update order

This is the orientation layer. The authoritative per-novel protocols live in `novel-writing-system/` in your project — `/renderer` tells Claude where to look and what order to follow.

---

## Installation (takes 30 seconds)

### Global install — available in every project

Copy the `.claude/commands/renderer.md` file from this zip to your home directory:

```bash
mkdir -p ~/.claude/commands
cp .claude/commands/renderer.md ~/.claude/commands/
```

### Project-local install — available only in this project

Copy the file into your project's `.claude/commands/` folder:

```bash
mkdir -p your-project/.claude/commands
cp .claude/commands/renderer.md your-project/.claude/commands/
```

---

## How to use it

1. Open Claude Code in a terminal or the desktop app
2. Navigate to your novel project directory (the one containing `novel-writing-system/`)
3. Type `/renderer` and press Enter
4. Tell Claude what you need — new chapter, review pass, canon assembly, etc.

**Example prompts after `/renderer`:**
- "Draft chapter 47. The context packet is in NovelDraft/temp/context_packet_ch47.md"
- "Run a prose review on the chapter in NovelDraft/drafts/ch12_draft.md"
- "Run lore consistency check on chapters 80–82"
- "Assemble ch 55 into canon and update the artifacts"

---

## Requirements

- Claude Code installed (CLI or desktop app)
- A project with `novel-writing-system/` in it
- Your novel's working files (NOVEL_CONFIGURATION.md, story primary, naming reference, anchor files)

If you don't have the framework files yet, download the full Renderer package from the GitHub button on the site.

---

## The full system

This skill is the Claude Code interface to the Renderer novel writing framework. The framework itself (pipeline documents, templates, protocols) is the `novel-writing-system/` folder available via the GitHub download.

**Renderer** — [renderer.piyakorn.com](https://renderer.piyakorn.com)
